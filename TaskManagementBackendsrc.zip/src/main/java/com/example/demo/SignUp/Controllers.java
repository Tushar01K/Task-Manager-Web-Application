package com.example.demo.SignUp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("*")
public class Controllers {
	@Autowired
	Services services;

	@PostMapping("register")
	public boolean register(@RequestBody User signup) {
		return services.save(signup);

	}
@GetMapping("login{UIEmail}and{UIPassword}")
public int login(@PathVariable String UIEmail,@PathVariable String UIPassword) {
	System.out.println(services.Signin(UIEmail,UIPassword));
	return services.Signin(UIEmail,UIPassword);
	
	
}

@PostMapping("addTask")
public boolean addTask(@RequestBody Task task) {
	return services.addtaskInDB(task);
}

@GetMapping("loadTaskFromDB")	
public List<Task> loadTaskFromDB() {
	return services.loadTask();
}

@PostMapping("editTask{taskName}")
public boolean editTask(@RequestBody Task task,@PathVariable String taskName) {
	return services.updateTaskInDB(task,taskName);
}
	
@GetMapping("getTask{taskName}")
public Task getTak(@PathVariable String taskName) {
	return services.getTaskFromName(taskName);
}

@GetMapping("deleteTask{taskeName}")
public boolean deleteTask(@PathVariable String taskName) {
	System.out.println(taskName);
	return services.deleteTaskFromDB(taskName);
}
	
}
