package com.example.demo.SignUp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.Respitories.TaskRepo;

@Service
public class Services {
	@Autowired
	Repository repository;
	@Autowired
   TaskRepo taskRepo;

	public boolean save(User signup) {
		 repository.save(signup);
		 return true;
	}

	public int Signin(String uIEmail, String uIPassword) {
		// TODO Auto-generated method stub

		User user = repository.getuserByEmailId(uIEmail);
		if (user.getEmail().equals(uIEmail)&& user.getPassword().equals(uIPassword)) {
			return 1;
		} else {
			return -1;
		}
		
	}

	public boolean addtaskInDB(Task task) {
		try {
			taskRepo.save(task);
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return false;
		}
	}

	public List<Task> loadTask() {
		try {
			return taskRepo.findAll();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
			// TODO: handle exception
		}
	}

	public boolean updateTaskInDB(Task task,String taskName) {
		try {
			Task task2 = taskRepo.findByTaskName(taskName);
			System.out.println(task2);
			if(task2.getTaskName().equals(taskName)) {
				task2.setDonePercentage(task.getDonePercentage());
				task2.setRemark(task.getRemark());
				task2.setEndDate(task.getEndDate());
				System.out.println(true);
				taskRepo.save(task2);
				return true;
			}
			else {
				return false;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	public Task getTaskFromName(String taskName) {
		Task task = taskRepo.findByTaskName(taskName);
		return task;
	}

	public boolean deleteTaskFromDB(String taskName) {
		try {
			System.out.println(taskName);
			taskRepo.deleteByTaskName(taskName);
//			Task task = taskRepo.findByTaskName(taskName);
//			int t = task.getId();
//			taskRepo.deleteById(t);
//			taskRepo.save(task);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		
	}
	
	
	

}
