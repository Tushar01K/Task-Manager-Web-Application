package com.example.demo.Respitories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.SignUp.Task;

@Repository
public interface TaskRepo extends JpaRepository<Task,Integer>{

	public Task findByTaskName(String taskName);
	
	public boolean deleteByTaskName(String taskName);
}
