import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserDashboardComponent } from './user-dashboard/user-dashboard.component';
import { LoginSignUpComponent } from './login-sign-up/login-sign-up.component';

const routes: Routes = [
  {path:'',redirectTo:'/LoginSignUpComponent', pathMatch:'full'},
  {path:'app-user-dashboard',component:UserDashboardComponent},
  {path:'LoginSignUpComponent',component:LoginSignUpComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
