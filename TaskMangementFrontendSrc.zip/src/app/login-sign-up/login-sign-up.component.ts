import { Component } from '@angular/core';
import { User } from '../Model/User';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { UserServiceService } from '../user-service.service';
import {  HostBinding } from '@angular/core';
// Import SkipHydrationDirective if using it


@Component({
  selector: 'app-login-sign-up',
  templateUrl: './login-sign-up.component.html',
  styleUrl: './login-sign-up.component.css'
  
})
export class LoginSignUpComponent {

  @HostBinding('attr.ngSkipHydration') skipHydration = false; // Or use directive's property

  constructor(private http:HttpClient,private router:Router,private service:UserServiceService){}
  url="http://localhost:8080/";

user:User=new User();
  UIEmail='';
UIPassword='';
login(){
  console.log(this.UIEmail+" "+this.UIPassword);
  
  this.http.get(this.url+"login"+this.UIEmail+'and'+this.UIPassword).subscribe((
    
    (data:any)=>{
      console.log(data);
      
      if(data==1){
        window.alert("Login Succesfully...");
        this.userDashboard();
        // this.islogin=data;
        // this.whatToShow=0;
      } 
    }
  ))
  }


  signup(){
    console.log(this.user)
    return this.service.add(this.user).subscribe((data:any)=>
      {
      this.signup=data;
      console.log("Registerde Successfully....");
      console.log(this.signup);
      if(data== true)
        window.alert("Registerde Successfully...")
      else
      window.alert("Exception on server...")
      }
      )
  }

  userDashboard(){
       this.router.navigateByUrl("app-user-dashboard");
    }
}
